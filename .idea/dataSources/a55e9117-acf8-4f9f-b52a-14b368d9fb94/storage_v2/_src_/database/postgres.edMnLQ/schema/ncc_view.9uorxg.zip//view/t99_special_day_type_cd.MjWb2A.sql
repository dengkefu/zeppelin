create view t99_special_day_type_cd
            (special_day_type_cd, special_day_subtype_cd, special_day_type_desc, special_day_subtype_desc) as
SELECT t99_special_day_type_cd.special_day_type_cd,
       t99_special_day_type_cd.special_day_subtype_cd,
       t99_special_day_type_cd.special_day_type_desc,
       t99_special_day_type_cd.special_day_subtype_desc
FROM ncc_pcode.t99_special_day_type_cd;

