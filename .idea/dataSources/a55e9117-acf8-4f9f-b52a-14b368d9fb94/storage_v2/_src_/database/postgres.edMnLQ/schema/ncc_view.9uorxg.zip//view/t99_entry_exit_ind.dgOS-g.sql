create view t99_entry_exit_ind(entry_exit_ind, entry_exit_desc) as
SELECT t99_entry_exit_ind.entry_exit_ind,
       t99_entry_exit_ind.entry_exit_desc
FROM ncc_pcode.t99_entry_exit_ind;

