create view t99_calendar
            (calendar_date, day_of_week, day_of_month, day_of_year, day_of_calendar, weekday_of_month, week_of_month,
             week_of_year, week_of_calendar, month_of_season, month_of_year, month_of_calendar, season_of_year,
             season_of_calendar, year_of_calendar, special_day_type_cd, special_day_id, special_day_name,
             special_day_start_end_ind, is_weekday_ind)
as
SELECT a.calendar_date,
       a.day_of_week,
       a.day_of_month,
       a.day_of_year,
       a.day_of_calendar,
       a.weekday_of_month,
       a.week_of_month,
       a.week_of_year,
       a.week_of_calendar,
       a.month_of_season,
       a.month_of_year,
       a.month_of_calendar,
       a.season_of_year,
       a.season_of_calendar,
       a.year_of_calendar,
       b.special_day_type_cd,
       b.special_day_id,
       b.special_day_name,
       CASE
           WHEN ((a.calendar_date = b.special_day_start_dt) AND (a.calendar_date = b.special_day_end_dt)) THEN 9
           WHEN (a.calendar_date = b.special_day_start_dt) THEN 0
           WHEN (a.calendar_date = b.special_day_end_dt) THEN 1
           ELSE NULL::integer
           END AS special_day_start_end_ind,
       CASE
           WHEN ((c.is_weekday_ind = 0) AND ((b.special_day_type_cd)::text = '01'::text)) THEN 2
           ELSE c.is_weekday_ind
           END AS is_weekday_ind
FROM ((ncc_pcode.t99_calendar a
    LEFT JOIN ncc_pdata.ta0_special_day b ON (((a.calendar_date >= b.special_day_start_dt) AND
                                               (a.calendar_date <= b.special_day_end_dt))))
         LEFT JOIN ncc_pdata.ta0_weekday c ON ((a.calendar_date = c.gregorian_date)));

