create view t99_trip_direction_cd(trip_drct_cd, trip_drct_desc) as
SELECT t99_trip_direction_cd.trip_drct_cd,
       t99_trip_direction_cd.trip_drct_desc
FROM ncc_pcode.t99_trip_direction_cd;

