create view t98_pasgr_qtty_all_st
            (stat_dt, stat_period_cd, stat_index_cd, prod_id, net_id, line_id, pasgr_quatity, data_dt) as
SELECT a.stat_dt,
       a.stat_period_cd,
       ''::character varying AS stat_index_cd,
       a.prod_id,
       '00'::text            AS net_id,
       a.line_id,
       a.pasgr_quatity,
       a.data_dt
FROM (ncc_pmart.t98_pasgr_qtty_date_st a
         JOIN ncc_pdata.t20_line d
              ON (((((((a.line_id)::text = (d.line_id)::text) AND ((d.head_line_cd)::text = '1'::text)) AND
                     ((d.line_id)::text <> '00'::text)) AND (a.data_dt >= date(d.open_tm))) AND
                   (a.data_dt < date(d.close_tm)))))
UNION ALL
SELECT a.stat_dt,
       a.stat_index_type_cd AS stat_period_cd,
       a.stat_index_cd,
       a.prod_id,
       '00'::text           AS net_id,
       a.line_id,
       a.pasgr_quatity,
       a.data_dt
FROM (ncc_pmart.t98_pasgr_qtty_period_st a
         JOIN ncc_pdata.t20_line d
              ON (((((((a.line_id)::text = (d.line_id)::text) AND ((d.head_line_cd)::text = '1'::text)) AND
                     ((d.line_id)::text <> '00'::text)) AND (a.data_dt >= date(d.open_tm))) AND
                   (a.data_dt < date(d.close_tm)))));

