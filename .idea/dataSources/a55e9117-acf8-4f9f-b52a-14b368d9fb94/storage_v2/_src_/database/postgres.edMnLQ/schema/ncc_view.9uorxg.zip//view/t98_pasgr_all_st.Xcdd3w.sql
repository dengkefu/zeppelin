create view t98_pasgr_all_st
            (stat_dt, stat_period_cd, stat_index_cd, prod_id, net_id, area_id, line_id, station_id, entry_quatity,
             exit_quatity, entry_exit_quatity, data_dt)
as
SELECT a.stat_dt,
       a.stat_period_cd,
       ''::bpchar    AS stat_index_cd,
       a.prod_id,
       '00'::text    AS net_id,
       c.district_id AS area_id,
       a.line_id,
       a.station_id,
       a.entry_quatity,
       a.exit_quatity,
       a.entry_exit_quatity,
       a.data_dt
FROM (((ncc_pmart.t98_pasgr_date_st a
    JOIN ncc_pdata.t20_station b ON (((a.station_id)::text = (b.station_id)::text)))
    JOIN ncc_pdata.t20_district c ON (((b.znoe)::text = (c.district_id)::text)))
         JOIN ncc_pdata.t20_line d
              ON ((((((a.line_id)::text = (d.line_id)::text) AND ((d.head_line_cd)::text = '1'::text)) AND
                    (a.data_dt >= date(d.open_tm))) AND (a.data_dt < date(d.close_tm)))))
UNION ALL
SELECT a.stat_dt,
       a.stat_index_type_cd AS stat_period_cd,
       a.stat_index_cd,
       a.prod_id,
       '00'::text           AS net_id,
       c.district_id        AS area_id,
       a.line_id,
       a.station_id,
       a.entry_quatity,
       a.exit_quatity,
       a.entry_exit_quatity,
       a.data_dt
FROM (((ncc_pmart.t98_pasgr_period_st a
    JOIN ncc_pdata.t20_station b ON (((a.station_id)::text = (b.station_id)::text)))
    JOIN ncc_pdata.t20_district c ON (((b.znoe)::text = (c.district_id)::text)))
         JOIN ncc_pdata.t20_line d
              ON ((((((a.line_id)::text = (d.line_id)::text) AND ((d.head_line_cd)::text = '1'::text)) AND
                    (a.data_dt >= date(d.open_tm))) AND (a.data_dt < date(d.close_tm)))));

