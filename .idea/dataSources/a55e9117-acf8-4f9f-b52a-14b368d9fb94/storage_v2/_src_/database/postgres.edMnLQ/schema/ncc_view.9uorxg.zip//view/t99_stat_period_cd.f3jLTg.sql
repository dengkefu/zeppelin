create view t99_stat_period_cd(stat_period_cd, stat_period_desc) as
SELECT t99_stat_period_cd.stat_period_cd,
       t99_stat_period_cd.stat_period_desc
FROM ncc_pcode.t99_stat_period_cd;

