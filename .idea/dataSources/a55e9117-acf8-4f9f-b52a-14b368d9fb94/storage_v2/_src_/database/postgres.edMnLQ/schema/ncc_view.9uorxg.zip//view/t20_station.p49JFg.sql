create view t20_station
            (station_id, station_name, station_eng_name, station_short_name, line_id, acc_station_id,
             start_terminal_station_ind, transfer_flag, xfer_station_id, station_status_cd, turnbackflag, longitude,
             latitude, ats_station_id, iscs_station_id, open_tm, close_tm, up_order, down_order, znoe, data_dt,
             acc_line_id)
as
SELECT t20_station.station_id,
       t20_station.station_name,
       t20_station.station_eng_name,
       t20_station.station_short_name,
       t20_station.line_id,
       t20_station.acc_station_id,
       t20_station.start_terminal_station_ind,
       t20_station.transfer_flag,
       t20_station.xfer_station_id,
       t20_station.station_status_cd,
       t20_station.turnbackflag,
       t20_station.longitude,
       t20_station.latitude,
       t20_station.ats_station_id,
       t20_station.iscs_station_id,
       t20_station.open_tm,
       t20_station.close_tm,
       t20_station.up_order,
       t20_station.down_order,
       t20_station.znoe,
       t20_station.data_dt,
       t20_station.acc_line_id
FROM ncc_pdata.t20_station;

