create view t20_transfer_station
            (xfer_station_id, xfer_station_nme, xfer_station_eng_name, xfer_station_lines, acc_xfer_station_id, open_tm,
             close_tm, data_dt)
as
SELECT t20_transfer_station.xfer_station_id,
       t20_transfer_station.xfer_station_nme,
       t20_transfer_station.xfer_station_eng_name,
       t20_transfer_station.xfer_station_lines,
       t20_transfer_station.acc_xfer_station_id,
       t20_transfer_station.open_tm,
       t20_transfer_station.close_tm,
       t20_transfer_station.data_dt
FROM ncc_pdata.t20_transfer_station;

