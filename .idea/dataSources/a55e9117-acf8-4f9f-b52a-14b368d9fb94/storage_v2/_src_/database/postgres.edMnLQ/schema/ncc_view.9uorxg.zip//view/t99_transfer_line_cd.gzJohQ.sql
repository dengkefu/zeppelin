create view t99_transfer_line_cd(line_id, traf_in_column_name, traf_out_column_name) as
SELECT t99_transfer_line_cd.line_id,
       t99_transfer_line_cd.traf_in_column_name,
       t99_transfer_line_cd.traf_out_column_name
FROM ncc_pcode.t99_transfer_line_cd;

