create view t98_sect_full_capacity_st
            (stat_dt, stat_index_type_cd, stat_index_cd, section_id, trip_drct_cd, full_capacity, data_dt) as
SELECT t98_sect_fcrate_period_st.stat_dt,
       t98_sect_fcrate_period_st.stat_index_type_cd,
       t98_sect_fcrate_period_st.stat_index_cd,
       t98_sect_fcrate_period_st.section_id,
       t98_sect_fcrate_period_st.trip_drct_cd,
       CASE
           WHEN (t98_sect_fcrate_period_st.section_trans_capacity = (0)::numeric) THEN (0)::numeric
           ELSE round((t98_sect_fcrate_period_st.sect_quatity / t98_sect_fcrate_period_st.section_trans_capacity), 2)
           END AS full_capacity,
       t98_sect_fcrate_period_st.data_dt
FROM ncc_pmart.t98_sect_fcrate_period_st;

