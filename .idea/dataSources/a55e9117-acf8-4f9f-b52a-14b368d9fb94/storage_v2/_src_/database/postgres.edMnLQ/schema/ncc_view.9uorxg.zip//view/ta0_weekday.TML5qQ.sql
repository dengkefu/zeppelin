create view ta0_weekday(gregorian_date, is_weekday_ind) as
SELECT ta0_weekday.gregorian_date,
       ta0_weekday.is_weekday_ind
FROM ncc_pdata.ta0_weekday;

