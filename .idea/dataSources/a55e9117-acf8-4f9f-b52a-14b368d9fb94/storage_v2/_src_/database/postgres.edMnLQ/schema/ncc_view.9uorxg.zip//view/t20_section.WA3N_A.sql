create view t20_section
            (section_id, section_name, line_id, trip_drct_cd, section_run_duration, section_stop_duration,
             section_run_distance, effect_dt, invalid_dt, valid_ind, section_start_station_id, section_end_station_id,
             data_dt, line_nme, section_start_station_name, section_end_station_name)
as
SELECT a.section_id,
       a.section_name,
       a.line_id,
       a.trip_drct_cd,
       a.section_run_duration,
       a.section_stop_duration,
       a.section_run_distance,
       a.effect_dt,
       a.invalid_dt,
       a.valid_ind,
       a.section_start_station_id,
       a.section_end_station_id,
       a.data_dt,
       b.line_nme,
       c.station_name AS section_start_station_name,
       d.station_name AS section_end_station_name
FROM (((ncc_pdata.t20_section a
    LEFT JOIN ncc_view.t20_station c ON (((a.section_start_station_id)::text = (c.station_id)::text)))
    LEFT JOIN ncc_view.t20_station d ON (((a.section_end_station_id)::text = (d.station_id)::text)))
         LEFT JOIN ncc_view.t20_line b
                   ON ((((a.line_id)::text = (b.line_id)::text) AND ((d.acc_line_id)::text = (b.acc_line_id)::text))))
WHERE ((a.valid_ind)::text = '10'::text);

