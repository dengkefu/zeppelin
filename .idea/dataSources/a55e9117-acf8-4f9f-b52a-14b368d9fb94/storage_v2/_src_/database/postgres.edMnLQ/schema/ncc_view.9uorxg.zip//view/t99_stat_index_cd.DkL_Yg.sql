create view t99_stat_index_cd
            (stat_index_cd, stat_index_type_cd, natural_day_index_cd, start_tm, end_tm, stat_end_tm, start_tm_desc,
             end_tm_desc, belong_five_min_index_cd, belong_ten_min_index_cd, belong_fif_min_index_cd,
             belong_thirty_min_index_cd, belong_one_hour_index_cd, belong_two_hour_index_cd)
as
SELECT t99_stat_index_cd.stat_index_cd,
       t99_stat_index_cd.stat_index_type_cd,
       t99_stat_index_cd.natural_day_index_cd,
       t99_stat_index_cd.start_tm,
       t99_stat_index_cd.end_tm,
       t99_stat_index_cd.stat_end_tm,
       t99_stat_index_cd.start_tm_desc,
       t99_stat_index_cd.end_tm_desc,
       t99_stat_index_cd.belong_five_min_index_cd,
       t99_stat_index_cd.belong_ten_min_index_cd,
       t99_stat_index_cd.belong_fif_min_index_cd,
       t99_stat_index_cd.belong_thirty_min_index_cd,
       t99_stat_index_cd.belong_one_hour_index_cd,
       t99_stat_index_cd.belong_two_hour_index_cd
FROM ncc_pcode.t99_stat_index_cd;

