create view t99_stat_index_type_cd(stat_index_type_cd, stat_index_type_desc) as
SELECT t99_stat_index_type_cd.stat_index_type_cd,
       t99_stat_index_type_cd.stat_index_type_desc
FROM ncc_pcode.t99_stat_index_type_cd;

