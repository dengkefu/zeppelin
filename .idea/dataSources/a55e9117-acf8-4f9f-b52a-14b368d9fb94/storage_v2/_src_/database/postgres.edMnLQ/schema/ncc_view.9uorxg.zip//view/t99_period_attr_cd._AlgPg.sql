create view t99_period_attr_cd (period_attr_cd, period_attr_desc, period_attr_start_tm, period_attr_end_tm) as
SELECT t99_period_attr_cd.period_attr_cd,
       t99_period_attr_cd.period_attr_desc,
       t99_period_attr_cd.period_attr_start_tm,
       t99_period_attr_cd.period_attr_end_tm
FROM ncc_pcode.t99_period_attr_cd;

