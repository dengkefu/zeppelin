create view t98_drct_imbalance_coef_sa_st
            (stat_dt, stat_index_type_cd, stat_index_cd, line_id, data_dt, drct_imbalance) as
SELECT t98_drct_imbalance_coef_st.stat_dt,
       t98_drct_imbalance_coef_st.stat_index_type_cd,
       t98_drct_imbalance_coef_st.stat_index_cd,
       t98_drct_imbalance_coef_st.line_id,
       t98_drct_imbalance_coef_st.data_dt,
       t98_drct_imbalance_coef_st.drct_imbalance
FROM ncc_pmart.t98_drct_imbalance_coef_st;

