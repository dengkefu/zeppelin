create view t99_product_tf_code
            (prod_id, ticket_type, parent_id, prod_nme, product_en_nm, prod_cate_cd, prod_issuer_id, ticket_family,
             souvenir_flag, namedsvticket_flag, sounddisplay_id, concessionallamp_id, row_flag, concessional_flag,
             effect_tm, invalid_tm, data_dt)
as
SELECT t50_product.prod_id,
       t50_product.ticket_type,
       t50_product.parent_id,
       t50_product.prod_nme,
       t50_product.product_en_nm,
       t50_product.prod_cate_cd,
       t50_product.prod_issuer_id,
       t50_product.ticket_family,
       t50_product.souvenir_flag,
       t50_product.namedsvticket_flag,
       t50_product.sounddisplay_id,
       t50_product.concessionallamp_id,
       t50_product.row_flag,
       t50_product.concessional_flag,
       t50_product.effect_tm,
       t50_product.invalid_tm,
       t50_product.data_dt
FROM ncc_pdata.t50_product;

