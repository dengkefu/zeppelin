create view t99_line_type_cd(line_type_cd, line_type_desc) as
SELECT t99_line_type_cd.line_type_cd,
       t99_line_type_cd.line_type_desc
FROM ncc_pcode.t99_line_type_cd;

