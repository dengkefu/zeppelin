create view t20_district (district_id, district_name, district_eng_name, area, population, remark) as
SELECT t20_district.district_id,
       t20_district.district_name,
       t20_district.district_eng_name,
       t20_district.area,
       t20_district.population,
       t20_district.remark
FROM ncc_pdata.t20_district;

