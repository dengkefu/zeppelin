create view ta0_special_day
            (special_day_id, special_day_type_cd, special_day_name, special_day_remark, special_day_start_dt,
             special_day_end_dt, data_dt, special_day_subtype_cd)
as
SELECT ta0_special_day.special_day_id,
       ta0_special_day.special_day_type_cd,
       ta0_special_day.special_day_name,
       ta0_special_day.special_day_remark,
       ta0_special_day.special_day_start_dt,
       ta0_special_day.special_day_end_dt,
       ta0_special_day.data_dt,
       ta0_special_day.special_day_subtype_cd
FROM ncc_pdata.ta0_special_day;

