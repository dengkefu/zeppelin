create view gp_bloat_expected_pages(btdrelid, btdrelpages, btdexppages) as
SELECT subq.btdrelid,
       subq.btdrelpages,
       CASE
           WHEN subq.btdexppages < subq.numsegments::numeric THEN subq.numsegments::numeric
           ELSE subq.btdexppages
           END AS btdexppages
FROM (SELECT pgc.oid                                            AS btdrelid,
             pgc.relpages                                       AS btdrelpages,
             ceil((pgc.reltuples * (25::double precision + btwcols.width))::numeric /
                  current_setting('block_size'::text)::numeric) AS btdexppages,
             (SELECT __gp_number_of_segments.numsegments
              FROM gp_toolkit.__gp_number_of_segments)          AS numsegments
      FROM (SELECT pgc_1.oid,
                   pgc_1.reltuples,
                   pgc_1.relpages
            FROM pg_class pgc_1
            WHERE NOT (EXISTS(SELECT __gp_is_append_only.iaooid
                              FROM gp_toolkit.__gp_is_append_only
                              WHERE __gp_is_append_only.iaooid = pgc_1.oid
                                AND __gp_is_append_only.iaotype = true))
              AND NOT (EXISTS(SELECT pg_partition.parrelid
                              FROM pg_partition
                              WHERE pg_partition.parrelid = pgc_1.oid))) pgc
               LEFT JOIN (SELECT pgs.starelid,
                                 sum(pgs.stawidth::double precision *
                                     (1.0::double precision - pgs.stanullfrac)) AS width
                          FROM pg_statistic pgs
                          GROUP BY pgs.starelid) btwcols ON pgc.oid = btwcols.starelid
      WHERE btwcols.starelid IS NOT NULL) subq;

alter table gp_bloat_expected_pages
    owner to gpadmin;

grant select on gp_bloat_expected_pages to public;

