create function __gp_skew_coefficients() returns SETOF gp_toolkit.gp_skew_analysis_t
    language plpgsql
as
$$
DECLARE
    skcoid oid;
    skcrec record;

BEGIN
    FOR skcoid IN SELECT autoid from gp_toolkit.__gp_user_data_tables_readable WHERE autrelstorage != 'x'
    LOOP
        SELECT * INTO skcrec
        FROM
            gp_toolkit.gp_skew_coefficient(skcoid);
        RETURN NEXT skcrec;
    END LOOP;
END
$$;

alter function __gp_skew_coefficients() owner to gpadmin;

