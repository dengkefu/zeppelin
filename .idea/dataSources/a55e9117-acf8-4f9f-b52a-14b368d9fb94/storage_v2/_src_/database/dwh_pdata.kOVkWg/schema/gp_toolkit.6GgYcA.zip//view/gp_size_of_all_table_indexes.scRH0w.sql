create view gp_size_of_all_table_indexes(soatioid, soatisize, soatischemaname, soatitablename) as
SELECT soati.soatioid,
       soati.soatisize,
       fn.fnnspname AS soatischemaname,
       fn.fnrelname AS soatitablename
FROM (SELECT ti.tireloid                                  AS soatioid,
             sum(pg_relation_size(ti.tiidxoid::regclass)) AS soatisize
      FROM gp_toolkit.gp_table_indexes ti
      GROUP BY ti.tireloid) soati
         JOIN gp_toolkit.__gp_fullname fn ON soati.soatioid = fn.fnoid;

alter table gp_size_of_all_table_indexes
    owner to gpadmin;

grant select on gp_size_of_all_table_indexes to public;

