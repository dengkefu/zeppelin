create view gp_size_of_table_disk
            (sotdoid, sotdsize, sotdtoastsize, sotdadditionalsize, sotdschemaname, sotdtablename) as
SELECT sotd.sotdoid,
       sotd.sotdsize,
       sotd.sotdtoastsize,
       sotd.sotdadditionalsize,
       fn.fnnspname AS sotdschemaname,
       fn.fnrelname AS sotdtablename
FROM (SELECT udtr.autoid                             AS sotdoid,
             pg_relation_size(udtr.autoid::regclass) AS sotdsize,
             CASE
                 WHEN udtr.auttoastoid > 0::oid THEN pg_total_relation_size(udtr.auttoastoid::regclass)
                 ELSE 0::bigint
                 END                                 AS sotdtoastsize,
             CASE
                 WHEN ao.segrelid IS NOT NULL AND ao.segrelid > 0::oid
                     THEN pg_total_relation_size(ao.segrelid::regclass)
                 ELSE 0::bigint
                 END +
             CASE
                 WHEN ao.blkdirrelid IS NOT NULL AND ao.blkdirrelid > 0::oid
                     THEN pg_total_relation_size(ao.blkdirrelid::regclass)
                 ELSE 0::bigint
                 END +
             CASE
                 WHEN ao.visimaprelid IS NOT NULL AND ao.visimaprelid > 0::oid
                     THEN pg_total_relation_size(ao.visimaprelid::regclass)
                 ELSE 0::bigint
                 END                                 AS sotdadditionalsize
      FROM (SELECT __gp_user_data_tables_readable.autnspname,
                   __gp_user_data_tables_readable.autrelname,
                   __gp_user_data_tables_readable.autrelkind,
                   __gp_user_data_tables_readable.autreltuples,
                   __gp_user_data_tables_readable.autrelpages,
                   __gp_user_data_tables_readable.autrelacl,
                   __gp_user_data_tables_readable.autoid,
                   __gp_user_data_tables_readable.auttoastoid,
                   __gp_user_data_tables_readable.autrelstorage
            FROM gp_toolkit.__gp_user_data_tables_readable
            WHERE __gp_user_data_tables_readable.autrelstorage <> 'x'::"char") udtr
               LEFT JOIN pg_appendonly ao ON udtr.autoid = ao.relid) sotd
         JOIN gp_toolkit.__gp_fullname fn ON sotd.sotdoid = fn.fnoid;

alter table gp_size_of_table_disk
    owner to gpadmin;

grant select on gp_size_of_table_disk to public;

