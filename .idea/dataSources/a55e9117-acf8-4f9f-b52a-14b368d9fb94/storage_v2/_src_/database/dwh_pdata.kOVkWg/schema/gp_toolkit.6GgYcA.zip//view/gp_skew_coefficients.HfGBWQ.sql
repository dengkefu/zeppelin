create view gp_skew_coefficients(skcoid, skcnamespace, skcrelname, skccoeff) as
SELECT skew.skewoid AS skcoid,
       pgn.nspname  AS skcnamespace,
       pgc.relname  AS skcrelname,
       skew.skewval AS skccoeff
FROM gp_toolkit.__gp_skew_coefficients() skew(skewoid, skewval)
         JOIN pg_class pgc ON skew.skewoid = pgc.oid
         JOIN pg_namespace pgn ON pgc.relnamespace = pgn.oid;

alter table gp_skew_coefficients
    owner to gpadmin;

grant select on gp_skew_coefficients to public;

