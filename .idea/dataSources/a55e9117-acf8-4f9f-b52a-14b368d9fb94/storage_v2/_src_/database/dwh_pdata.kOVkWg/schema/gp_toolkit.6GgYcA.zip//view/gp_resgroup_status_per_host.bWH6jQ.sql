create view gp_resgroup_status_per_host
            (rsgname, groupid, hostname, cpu, memory_used, memory_available, memory_quota_used, memory_quota_available,
             memory_shared_used, memory_shared_available)
as
WITH s AS (
    SELECT gp_resgroup_status.rsgname,
           gp_resgroup_status.groupid,
           (json_each(gp_resgroup_status.cpu_usage)).key::smallint AS segment_id,
           (json_each(gp_resgroup_status.cpu_usage)).value         AS cpu,
           (json_each(gp_resgroup_status.memory_usage)).value      AS memory
    FROM gp_toolkit.gp_resgroup_status
)
SELECT s.rsgname,
       s.groupid,
       c.hostname,
       round(avg(s.cpu::text::numeric), 2)                          AS cpu,
       sum(((s.memory -> 'used'::text)::text)::integer)             AS memory_used,
       sum(((s.memory -> 'available'::text)::text)::integer)        AS memory_available,
       sum(((s.memory -> 'quota_used'::text)::text)::integer)       AS memory_quota_used,
       sum(((s.memory -> 'quota_available'::text)::text)::integer)  AS memory_quota_available,
       sum(((s.memory -> 'shared_used'::text)::text)::integer)      AS memory_shared_used,
       sum(((s.memory -> 'shared_available'::text)::text)::integer) AS memory_shared_available
FROM s
         JOIN gp_segment_configuration c ON s.segment_id = c.content AND c.role = 'p'::"char"
GROUP BY s.rsgname, s.groupid, c.hostname;

alter table gp_resgroup_status_per_host
    owner to gpadmin;

grant select on gp_resgroup_status_per_host to public;

