create view gp_resq_activity_by_queue(resqoid, resqname, resqlast, resqstatus, resqtotal) as
SELECT gp_resq_activity.resqoid,
       gp_resq_activity.resqname,
       max(gp_resq_activity.resqstart) AS resqlast,
       gp_resq_activity.resqstatus,
       count(*)                        AS resqtotal
FROM gp_toolkit.gp_resq_activity
GROUP BY gp_resq_activity.resqoid, gp_resq_activity.resqname, gp_resq_activity.resqstatus
ORDER BY gp_resq_activity.resqoid, max(gp_resq_activity.resqstart);

alter table gp_resq_activity_by_queue
    owner to gpadmin;

grant select on gp_resq_activity_by_queue to public;

