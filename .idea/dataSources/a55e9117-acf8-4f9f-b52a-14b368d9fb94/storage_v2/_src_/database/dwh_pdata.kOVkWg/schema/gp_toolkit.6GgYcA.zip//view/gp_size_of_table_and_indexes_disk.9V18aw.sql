create view gp_size_of_table_and_indexes_disk
            (sotaidoid, sotaidtablesize, sotaididxsize, sotaidschemaname, sotaidtablename) as
SELECT sotaid.sotaidoid,
       sotaid.sotaidtablesize,
       sotaid.sotaididxsize,
       fn.fnnspname AS sotaidschemaname,
       fn.fnrelname AS sotaidtablename
FROM (SELECT sotd.sotdoid                                                 AS sotaidoid,
             sotd.sotdsize + sotd.sotdtoastsize + sotd.sotdadditionalsize AS sotaidtablesize,
             CASE
                 WHEN soati.soatisize IS NULL THEN 0::numeric
                 ELSE soati.soatisize
                 END                                                      AS sotaididxsize
      FROM gp_toolkit.gp_size_of_table_disk sotd
               LEFT JOIN gp_toolkit.gp_size_of_all_table_indexes soati ON sotd.sotdoid = soati.soatioid) sotaid
         JOIN gp_toolkit.__gp_fullname fn ON sotaid.sotaidoid = fn.fnoid;

alter table gp_size_of_table_and_indexes_disk
    owner to gpadmin;

grant select on gp_size_of_table_and_indexes_disk to public;

