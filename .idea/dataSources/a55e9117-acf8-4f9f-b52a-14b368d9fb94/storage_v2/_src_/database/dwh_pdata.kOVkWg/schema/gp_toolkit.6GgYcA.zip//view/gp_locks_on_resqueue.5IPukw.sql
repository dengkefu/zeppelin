create view gp_locks_on_resqueue
            (lorusename, lorrsqname, lorlocktype, lorobjid, lortransaction, lorpid, lormode, lorgranted, lorwaiting) as
SELECT pgsa.usename      AS lorusename,
       pgrq.rsqname      AS lorrsqname,
       pgl.locktype      AS lorlocktype,
       pgl.objid         AS lorobjid,
       pgl.transactionid AS lortransaction,
       pgl.pid           AS lorpid,
       pgl.mode          AS lormode,
       pgl.granted       AS lorgranted,
       pgsa.waiting      AS lorwaiting
FROM pg_stat_activity pgsa
         JOIN pg_locks pgl ON pgsa.pid = pgl.pid
         JOIN pg_resqueue pgrq ON pgl.objid = pgrq.oid;

alter table gp_locks_on_resqueue
    owner to gpadmin;

grant select on gp_locks_on_resqueue to public;

