create view gp_workfile_mgr_used_diskspace(segid, bytes) as
SELECT c.segid,
       c.bytes
FROM gp_toolkit.__gp_workfile_mgr_used_diskspace_f_on_master() c(segid integer, bytes bigint)
UNION ALL
SELECT c.segid,
       c.bytes
FROM gp_toolkit.__gp_workfile_mgr_used_diskspace_f_on_segments() c(segid integer, bytes bigint)
ORDER BY 1;

alter table gp_workfile_mgr_used_diskspace
    owner to gpadmin;

grant select on gp_workfile_mgr_used_diskspace to public;

