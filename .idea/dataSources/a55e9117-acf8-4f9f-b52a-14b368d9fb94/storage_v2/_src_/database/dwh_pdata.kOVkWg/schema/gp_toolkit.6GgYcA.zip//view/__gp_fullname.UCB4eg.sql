create view __gp_fullname(fnoid, fnnspname, fnrelname) as
SELECT pgc.oid     AS fnoid,
       pgn.nspname AS fnnspname,
       pgc.relname AS fnrelname
FROM pg_class pgc,
     pg_namespace pgn
WHERE pgc.relnamespace = pgn.oid;

alter table __gp_fullname
    owner to gpadmin;

grant select on __gp_fullname to public;

