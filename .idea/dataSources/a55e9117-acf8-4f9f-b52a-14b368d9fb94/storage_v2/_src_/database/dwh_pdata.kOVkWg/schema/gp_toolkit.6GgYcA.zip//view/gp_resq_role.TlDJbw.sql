create view gp_resq_role(rrrolname, rrrsqname) as
SELECT pgr.rolname  AS rrrolname,
       pgrq.rsqname AS rrrsqname
FROM pg_roles pgr
         LEFT JOIN pg_resqueue pgrq ON pgr.rolresqueue = pgrq.oid;

alter table gp_resq_role
    owner to gpadmin;

grant select on gp_resq_role to public;

