create view gp_size_of_table_uncompressed(sotuoid, sotusize, sotuschemaname, sotutablename) as
SELECT sotu.sotuoid,
       sotu.sotusize,
       fn.fnnspname AS sotuschemaname,
       fn.fnrelname AS sotutablename
FROM (SELECT sotd.sotdoid                                                                               AS sotuoid,
             CASE
                 WHEN iao.iaotype THEN
                     CASE
                         WHEN pg_relation_size(sotd.sotdoid::regclass) = 0 THEN 0::double precision
                         ELSE pg_relation_size(sotd.sotdoid::regclass)::double precision *
                              CASE
                                  WHEN get_ao_compression_ratio(sotd.sotdoid::regclass) = (-1)::double precision
                                      THEN NULL::double precision
                                  ELSE get_ao_compression_ratio(sotd.sotdoid::regclass)
                                  END
                         END
                 ELSE sotd.sotdsize::double precision
                 END + sotd.sotdtoastsize::double precision + sotd.sotdadditionalsize::double precision AS sotusize
      FROM gp_toolkit.gp_size_of_table_disk sotd
               JOIN gp_toolkit.__gp_is_append_only iao ON sotd.sotdoid = iao.iaooid) sotu
         JOIN gp_toolkit.__gp_fullname fn ON sotu.sotuoid = fn.fnoid;

alter table gp_size_of_table_uncompressed
    owner to gpadmin;

