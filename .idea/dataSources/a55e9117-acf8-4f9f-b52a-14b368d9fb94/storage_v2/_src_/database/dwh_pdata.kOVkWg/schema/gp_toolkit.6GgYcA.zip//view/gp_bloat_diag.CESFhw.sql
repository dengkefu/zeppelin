create view gp_bloat_diag(bdirelid, bdinspname, bdirelname, bdirelpages, bdiexppages, bdidiag) as
SELECT bloatsummary.btdrelid     AS bdirelid,
       bloatsummary.fnnspname    AS bdinspname,
       bloatsummary.fnrelname    AS bdirelname,
       bloatsummary.btdrelpages  AS bdirelpages,
       bloatsummary.btdexppages  AS bdiexppages,
       (bloatsummary.bd).bltdiag AS bdidiag
FROM (SELECT fn.fnoid,
             fn.fnnspname,
             fn.fnrelname,
             beg.btdrelid,
             beg.btdrelpages,
             beg.btdexppages,
             gp_toolkit.gp_bloat_diag(beg.btdrelpages, beg.btdexppages, iao.iaotype) AS bd
      FROM gp_toolkit.gp_bloat_expected_pages beg,
           pg_class pgc,
           gp_toolkit.__gp_fullname fn,
           gp_toolkit.__gp_is_append_only iao
      WHERE beg.btdrelid = pgc.oid
        AND pgc.oid = fn.fnoid
        AND iao.iaooid = pgc.oid) bloatsummary
WHERE (bloatsummary.bd).bltidx > 0;

alter table gp_bloat_diag
    owner to gpadmin;

grant select on gp_bloat_diag to public;

