create function gp_param_setting(character varying) returns SETOF gp_toolkit.gp_param_setting_t
    language sql
as
$$
SELECT * FROM gp_toolkit.__gp_param_setting_on_master($1)
  UNION ALL
  SELECT * FROM gp_toolkit.__gp_param_setting_on_segments($1);
$$;

alter function gp_param_setting(varchar) owner to gpadmin;

