create view gp_log_database
            (logtime, loguser, logdatabase, logpid, logthread, loghost, logport, logsessiontime, logtransaction,
             logsession, logcmdcount, logsegment, logslice, logdistxact, loglocalxact, logsubxact, logseverity,
             logstate, logmessage, logdetail, loghint, logquery, logquerypos, logcontext, logdebug, logcursorpos,
             logfunction, logfile, logline, logstack)
as
SELECT gp_log_system.logtime,
       gp_log_system.loguser,
       gp_log_system.logdatabase,
       gp_log_system.logpid,
       gp_log_system.logthread,
       gp_log_system.loghost,
       gp_log_system.logport,
       gp_log_system.logsessiontime,
       gp_log_system.logtransaction,
       gp_log_system.logsession,
       gp_log_system.logcmdcount,
       gp_log_system.logsegment,
       gp_log_system.logslice,
       gp_log_system.logdistxact,
       gp_log_system.loglocalxact,
       gp_log_system.logsubxact,
       gp_log_system.logseverity,
       gp_log_system.logstate,
       gp_log_system.logmessage,
       gp_log_system.logdetail,
       gp_log_system.loghint,
       gp_log_system.logquery,
       gp_log_system.logquerypos,
       gp_log_system.logcontext,
       gp_log_system.logdebug,
       gp_log_system.logcursorpos,
       gp_log_system.logfunction,
       gp_log_system.logfile,
       gp_log_system.logline,
       gp_log_system.logstack
FROM gp_toolkit.gp_log_system
WHERE gp_log_system.logdatabase = current_database()::text;

alter table gp_log_database
    owner to gpadmin;

