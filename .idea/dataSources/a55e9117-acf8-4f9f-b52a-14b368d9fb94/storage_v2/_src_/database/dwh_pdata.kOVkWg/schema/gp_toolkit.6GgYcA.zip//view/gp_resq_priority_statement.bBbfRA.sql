create view gp_resq_priority_statement
            (rqpdatname, rqpusename, rqpsession, rqpcommand, rqppriority, rqpweight, rqpquery) as
SELECT psa.datname AS rqpdatname,
       psa.usename AS rqpusename,
       rpb.rqpsession,
       rpb.rqpcommand,
       rpb.rqppriority,
       rpb.rqpweight,
       psa.query   AS rqpquery
FROM gp_toolkit.gp_resq_priority_backend rpb
         JOIN pg_stat_activity psa ON rpb.rqpsession = psa.sess_id
WHERE psa.query <> '<IDLE>'::text;

alter table gp_resq_priority_statement
    owner to gpadmin;

grant select on gp_resq_priority_statement to public;

