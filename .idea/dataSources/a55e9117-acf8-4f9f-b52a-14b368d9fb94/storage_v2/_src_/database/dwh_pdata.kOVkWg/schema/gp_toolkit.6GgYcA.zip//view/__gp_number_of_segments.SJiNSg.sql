create view __gp_number_of_segments(numsegments) as
SELECT count(*)::smallint AS numsegments
FROM gp_segment_configuration
WHERE gp_segment_configuration.preferred_role = 'p'::"char"
  AND gp_segment_configuration.content >= 0;

alter table __gp_number_of_segments
    owner to gpadmin;

grant select on __gp_number_of_segments to public;

