create view gp_workfile_entries
            (datname, pid, sess_id, command_cnt, usename, query, segid, slice, optype, size, numfiles, prefix) as
WITH all_entries AS (
    SELECT c_1.segid,
           c_1.prefix,
           c_1.size,
           c_1.optype,
           c_1.slice,
           c_1.sessionid,
           c_1.commandid,
           c_1.numfiles
    FROM gp_toolkit.__gp_workfile_entries_f_on_master() c_1(segid integer, prefix text, size bigint, optype text,
                                                            slice integer, sessionid integer, commandid integer,
                                                            numfiles integer)
    UNION ALL
    SELECT c_1.segid,
           c_1.prefix,
           c_1.size,
           c_1.optype,
           c_1.slice,
           c_1.sessionid,
           c_1.commandid,
           c_1.numfiles
    FROM gp_toolkit.__gp_workfile_entries_f_on_segments() c_1(segid integer, prefix text, size bigint, optype text,
                                                              slice integer, sessionid integer, commandid integer,
                                                              numfiles integer)
)
SELECT s.datname,
       s.pid,
       c.sessionid AS sess_id,
       c.commandid AS command_cnt,
       s.usename,
       s.query,
       c.segid,
       c.slice,
       c.optype,
       c.size,
       c.numfiles,
       c.prefix
FROM all_entries c
         LEFT JOIN pg_stat_activity s ON c.sessionid = s.sess_id;

alter table gp_workfile_entries
    owner to gpadmin;

grant select on gp_workfile_entries to public;

