create view __gp_user_data_tables
            (autnspname, autrelname, autrelkind, autreltuples, autrelpages, autrelacl, autoid, auttoastoid,
             autrelstorage) as
SELECT aut.autnspname,
       aut.autrelname,
       aut.autrelkind,
       aut.autreltuples,
       aut.autrelpages,
       aut.autrelacl,
       aut.autoid,
       aut.auttoastoid,
       aut.autrelstorage
FROM gp_toolkit.__gp_user_tables aut
         LEFT JOIN pg_partition pgp ON aut.autoid = pgp.parrelid
WHERE pgp.parrelid IS NULL;

alter table __gp_user_data_tables
    owner to gpadmin;

grant select on __gp_user_data_tables to public;

