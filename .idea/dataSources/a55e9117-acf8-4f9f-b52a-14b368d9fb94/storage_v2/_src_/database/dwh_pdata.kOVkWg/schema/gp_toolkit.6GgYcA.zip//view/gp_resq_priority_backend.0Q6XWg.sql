create view gp_resq_priority_backend(rqpsession, rqpcommand, rqppriority, rqpweight) as
SELECT l.session_id    AS rqpsession,
       l.command_count AS rqpcommand,
       l.priority      AS rqppriority,
       l.weight        AS rqpweight
FROM gp_list_backend_priorities() l(session_id integer, command_count integer, priority text, weight integer);

alter table gp_resq_priority_backend
    owner to gpadmin;

grant select on gp_resq_priority_backend to public;

