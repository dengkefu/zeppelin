create function gp_skew_details(oid) returns SETOF gp_toolkit.gp_skew_details_t
    language plpgsql
as
$$
DECLARE
    skewcrs refcursor;
    skewrec record;
    skewarray bigint[];
    skewaot bool;
    skewsegid int;
    skewtablename record;
    skewreplicated record;

BEGIN

    SELECT INTO skewrec *
    FROM pg_catalog.pg_appendonly pga, pg_catalog.pg_roles pgr
    WHERE pga.relid = $1::regclass and pgr.rolname = current_user and pgr.rolsuper = 't';

    IF FOUND THEN
        -- append only table

        FOR skewrec IN
            SELECT $1, segid, COALESCE(tupcount, 0)::bigint AS cnt
            FROM (SELECT generate_series(0, numsegments - 1) FROM gp_toolkit.__gp_number_of_segments) segs(segid)
            LEFT OUTER JOIN pg_catalog.get_ao_distribution($1)
            ON segid = segmentid
        LOOP
            RETURN NEXT skewrec;
        END LOOP;

    ELSE
        -- heap table

        SELECT * INTO skewtablename FROM gp_toolkit.__gp_fullname
        WHERE fnoid = $1;

        SELECT * INTO skewreplicated FROM gp_distribution_policy WHERE policytype = 'r' AND localoid = $1;

        IF FOUND THEN
            -- replicated table, gp_segment_id is user-invisible and all replicas have same count of tuples.
            OPEN skewcrs
                FOR
                EXECUTE
                    'SELECT ' || $1 || '::oid, segid, ' ||
                    '(' ||
                        'SELECT COUNT(*) AS cnt FROM ' ||
                        quote_ident(skewtablename.fnnspname) ||
                        '.' ||
                        quote_ident(skewtablename.fnrelname) ||
                    ') '
                    'FROM (SELECT generate_series(0, numsegments - 1) FROM gp_toolkit.__gp_number_of_segments) segs(segid)';
        ELSE
            OPEN skewcrs
                FOR
                EXECUTE
                    'SELECT ' || $1 || '::oid, segid, CASE WHEN gp_segment_id IS NULL THEN 0 ELSE cnt END ' ||
                    'FROM (SELECT generate_series(0, numsegments - 1) FROM gp_toolkit.__gp_number_of_segments) segs(segid) ' ||
                    'LEFT OUTER JOIN ' ||
                        '(SELECT gp_segment_id, COUNT(*) AS cnt FROM ' ||
                            quote_ident(skewtablename.fnnspname) ||
                            '.' ||
                            quote_ident(skewtablename.fnrelname) ||
                        ' GROUP BY 1) details ' ||
                    'ON segid = gp_segment_id';
        END IF;

        FOR skewsegid IN
            SELECT generate_series(1, numsegments)
            FROM gp_toolkit.__gp_number_of_segments
        LOOP
            FETCH skewcrs INTO skewrec;
            IF FOUND THEN
                RETURN NEXT skewrec;
            ELSE
                RETURN;
            END IF;
        END LOOP;
        CLOSE skewcrs;
    END IF;

    RETURN;
END
$$;

alter function gp_skew_details(oid) owner to gpadmin;

