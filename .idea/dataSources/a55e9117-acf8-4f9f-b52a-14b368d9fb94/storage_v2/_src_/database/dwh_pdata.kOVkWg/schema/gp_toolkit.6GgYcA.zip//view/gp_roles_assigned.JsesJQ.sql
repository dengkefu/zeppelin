create view gp_roles_assigned(raroleid, rarolename, ramemberid, ramembername) as
SELECT pgr.oid      AS raroleid,
       pgr.rolname  AS rarolename,
       pgam.member  AS ramemberid,
       pgr2.rolname AS ramembername
FROM pg_roles pgr
         LEFT JOIN pg_auth_members pgam ON pgr.oid = pgam.roleid
         LEFT JOIN pg_roles pgr2 ON pgam.member = pgr2.oid;

alter table gp_roles_assigned
    owner to gpadmin;

grant select on gp_roles_assigned to public;

