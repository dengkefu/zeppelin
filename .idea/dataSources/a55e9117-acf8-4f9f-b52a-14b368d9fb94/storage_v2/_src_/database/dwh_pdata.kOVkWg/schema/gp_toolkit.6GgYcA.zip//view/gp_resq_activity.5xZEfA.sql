create view gp_resq_activity(resqprocpid, resqrole, resqoid, resqname, resqstart, resqstatus) as
SELECT psa.pid         AS resqprocpid,
       psa.usename     AS resqrole,
       resq.resqoid,
       resq.rsqname    AS resqname,
       psa.query_start AS resqstart,
       CASE
           WHEN resq.resqgranted = false THEN 'waiting'::text
           ELSE 'running'::text
           END         AS resqstatus
FROM pg_stat_activity psa
         JOIN (SELECT pgrq.oid    AS resqoid,
                      pgrq.rsqname,
                      pgl.pid     AS resqprocid,
                      pgl.granted AS resqgranted
               FROM pg_resqueue pgrq,
                    pg_locks pgl
               WHERE pgl.objid = pgrq.oid) resq ON resq.resqprocid = psa.pid
WHERE psa.query <> '<IDLE>'::text
ORDER BY psa.query_start;

alter table gp_resq_activity
    owner to gpadmin;

grant select on gp_resq_activity to public;

