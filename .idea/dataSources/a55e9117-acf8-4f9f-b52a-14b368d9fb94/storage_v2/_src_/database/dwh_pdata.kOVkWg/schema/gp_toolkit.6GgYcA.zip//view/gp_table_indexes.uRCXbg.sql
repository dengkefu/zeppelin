create view gp_table_indexes (tireloid, tiidxoid, titableschemaname, titablename, tiindexschemaname, tiindexname) as
SELECT ti.tireloid,
       ti.tiidxoid,
       fntbl.fnnspname AS titableschemaname,
       fntbl.fnrelname AS titablename,
       fnidx.fnnspname AS tiindexschemaname,
       fnidx.fnrelname AS tiindexname
FROM (SELECT pgc.oid  AS tireloid,
             pgc2.oid AS tiidxoid
      FROM pg_class pgc
               JOIN pg_index pgi ON pgc.oid = pgi.indrelid
               JOIN pg_class pgc2 ON pgi.indexrelid = pgc2.oid
               JOIN gp_toolkit.__gp_user_data_tables_readable udt ON udt.autoid = pgc.oid) ti
         JOIN gp_toolkit.__gp_fullname fntbl ON ti.tireloid = fntbl.fnoid
         JOIN gp_toolkit.__gp_fullname fnidx ON ti.tiidxoid = fnidx.fnoid;

alter table gp_table_indexes
    owner to gpadmin;

grant select on gp_table_indexes to public;

