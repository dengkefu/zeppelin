create function gp_skew_idle_fraction(targetoid oid, OUT sifoid oid, OUT siffraction numeric) returns record
    language sql
as
$$
SELECT
        $1 as sifoid,
        CASE
            WHEN MIN(skewmax) = 0 THEN 0
            ELSE (SUM(skewmax - segtupcount) / (MIN(skewmax) * MIN(numsegments)))
        END
        AS siffraction
    FROM
    (
        SELECT segid, segtupcount, COUNT(segid) OVER () AS numsegments, MAX(segtupcount) OVER () AS skewmax
        FROM gp_toolkit.gp_skew_details($1)
    ) AS skewbaseline

$$;

alter function gp_skew_idle_fraction(oid, out oid, out numeric) owner to gpadmin;

