create view __gp_user_tables
            (autnspname, autrelname, autrelkind, autreltuples, autrelpages, autrelacl, autoid, auttoastoid,
             autrelstorage) as
SELECT fn.fnnspname      AS autnspname,
       fn.fnrelname      AS autrelname,
       pgc.relkind       AS autrelkind,
       pgc.reltuples     AS autreltuples,
       pgc.relpages      AS autrelpages,
       pgc.relacl        AS autrelacl,
       pgc.oid           AS autoid,
       pgc.reltoastrelid AS auttoastoid,
       pgc.relstorage    AS autrelstorage
FROM pg_class pgc,
     gp_toolkit.__gp_fullname fn
WHERE (pgc.relnamespace IN (SELECT __gp_user_namespaces.aunoid
                            FROM gp_toolkit.__gp_user_namespaces))
  AND pgc.relkind = 'r'::"char"
  AND pgc.oid = fn.fnoid;

alter table __gp_user_tables
    owner to gpadmin;

grant select on __gp_user_tables to public;

