create view gp_workfile_usage_per_segment(segid, size, numfiles) as
SELECT gpseg.content                       AS segid,
       COALESCE(sum(wfe.size), 0::numeric) AS size,
       sum(wfe.numfiles)                   AS numfiles
FROM (SELECT gp_segment_configuration.content
      FROM gp_segment_configuration
      WHERE gp_segment_configuration.role = 'p'::"char") gpseg
         LEFT JOIN gp_toolkit.gp_workfile_entries wfe ON gpseg.content = wfe.segid
GROUP BY gpseg.content;

alter table gp_workfile_usage_per_segment
    owner to gpadmin;

grant select on gp_workfile_usage_per_segment to public;

