create view gp_size_of_table_and_indexes_licensing
            (sotailoid, sotailtablesizedisk, sotailtablesizeuncompressed, sotailindexessize, sotailschemaname,
             sotailtablename) as
SELECT sotail.sotailoid,
       sotail.sotailtablesizedisk,
       sotail.sotailtablesizeuncompressed,
       sotail.sotailindexessize,
       fn.fnnspname AS sotailschemaname,
       fn.fnrelname AS sotailtablename
FROM (SELECT sotu.sotuoid           AS sotailoid,
             sotaid.sotaidtablesize AS sotailtablesizedisk,
             sotu.sotusize          AS sotailtablesizeuncompressed,
             sotaid.sotaididxsize   AS sotailindexessize
      FROM gp_toolkit.gp_size_of_table_uncompressed sotu
               JOIN gp_toolkit.gp_size_of_table_and_indexes_disk sotaid ON sotu.sotuoid = sotaid.sotaidoid) sotail
         JOIN gp_toolkit.__gp_fullname fn ON sotail.sotailoid = fn.fnoid;

alter table gp_size_of_table_and_indexes_licensing
    owner to gpadmin;

