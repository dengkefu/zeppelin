create view gp_resqueue_status
            (queueid, rsqname, rsqcountlimit, rsqcountvalue, rsqcostlimit, rsqcostvalue, rsqmemorylimit, rsqmemoryvalue,
             rsqwaiters, rsqholders)
as
SELECT q.oid             AS queueid,
       q.rsqname,
       t1.value::integer AS rsqcountlimit,
       t2.value::integer AS rsqcountvalue,
       t3.value::real    AS rsqcostlimit,
       t4.value::real    AS rsqcostvalue,
       t5.value::real    AS rsqmemorylimit,
       t6.value::real    AS rsqmemoryvalue,
       t7.value::integer AS rsqwaiters,
       t8.value::integer AS rsqholders
FROM pg_resqueue q,
     pg_resqueue_status_kv() t1(queueid oid, key text, value text),
     pg_resqueue_status_kv() t2(queueid oid, key text, value text),
     pg_resqueue_status_kv() t3(queueid oid, key text, value text),
     pg_resqueue_status_kv() t4(queueid oid, key text, value text),
     pg_resqueue_status_kv() t5(queueid oid, key text, value text),
     pg_resqueue_status_kv() t6(queueid oid, key text, value text),
     pg_resqueue_status_kv() t7(queueid oid, key text, value text),
     pg_resqueue_status_kv() t8(queueid oid, key text, value text)
WHERE q.oid = t1.queueid
  AND t1.queueid = t2.queueid
  AND t2.queueid = t3.queueid
  AND t3.queueid = t4.queueid
  AND t4.queueid = t5.queueid
  AND t5.queueid = t6.queueid
  AND t6.queueid = t7.queueid
  AND t7.queueid = t8.queueid
  AND t1.key = 'rsqcountlimit'::text
  AND t2.key = 'rsqcountvalue'::text
  AND t3.key = 'rsqcostlimit'::text
  AND t4.key = 'rsqcostvalue'::text
  AND t5.key = 'rsqmemorylimit'::text
  AND t6.key = 'rsqmemoryvalue'::text
  AND t7.key = 'rsqwaiters'::text
  AND t8.key = 'rsqholders'::text;

alter table gp_resqueue_status
    owner to gpadmin;

grant select on gp_resqueue_status to public;

