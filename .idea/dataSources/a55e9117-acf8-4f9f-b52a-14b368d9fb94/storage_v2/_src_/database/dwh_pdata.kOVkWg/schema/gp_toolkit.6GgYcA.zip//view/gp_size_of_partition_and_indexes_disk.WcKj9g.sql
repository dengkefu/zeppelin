create view gp_size_of_partition_and_indexes_disk
            (sopaidparentoid, sopaidpartitionoid, sopaidpartitiontablesize, sopaidpartitionindexessize,
             sopaidparentschemaname, sopaidparenttablename, sopaidpartitionschemaname, sopaidpartitiontablename)
as
SELECT sopaid.sopaidparentoid,
       sopaid.sopaidpartitionoid,
       sopaid.sopaidpartitiontablesize,
       sopaid.sopaidpartitionindexessize,
       fnparent.fnnspname AS sopaidparentschemaname,
       fnparent.fnrelname AS sopaidparenttablename,
       fnpart.fnnspname   AS sopaidpartitionschemaname,
       fnpart.fnrelname   AS sopaidpartitiontablename
FROM (SELECT pgp.parrelid                                                 AS sopaidparentoid,
             pgpr.parchildrelid                                           AS sopaidpartitionoid,
             sotd.sotdsize + sotd.sotdtoastsize + sotd.sotdadditionalsize AS sopaidpartitiontablesize,
             COALESCE(soati.soatisize, 0::numeric)                        AS sopaidpartitionindexessize
      FROM pg_partition pgp
               JOIN pg_partition_rule pgpr ON pgp.oid = pgpr.paroid
               JOIN gp_toolkit.gp_size_of_table_disk sotd ON sotd.sotdoid = pgpr.parchildrelid
               LEFT JOIN gp_toolkit.gp_size_of_all_table_indexes soati ON soati.soatioid = pgpr.parchildrelid) sopaid
         JOIN gp_toolkit.__gp_fullname fnparent ON sopaid.sopaidparentoid = fnparent.fnoid
         JOIN gp_toolkit.__gp_fullname fnpart ON sopaid.sopaidpartitionoid = fnpart.fnoid;

alter table gp_size_of_partition_and_indexes_disk
    owner to gpadmin;

grant select on gp_size_of_partition_and_indexes_disk to public;

