create function __gp_aovisimap_hidden_typed(oid) returns SETOF gp_toolkit.__gp_aovisimap_hidden_t
    language sql
as
$$
SELECT * FROM gp_toolkit.__gp_aovisimap_hidden_info($1);
$$;

alter function __gp_aovisimap_hidden_typed(oid) owner to gpadmin;

