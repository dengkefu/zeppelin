create view gp_locks_on_relation
            (lorlocktype, lordatabase, lorrelname, lorrelation, lortransaction, lorpid, lormode, lorgranted,
             lorcurrentquery) as
SELECT pgl.locktype      AS lorlocktype,
       pgl.database      AS lordatabase,
       pgc.relname       AS lorrelname,
       pgl.relation      AS lorrelation,
       pgl.transactionid AS lortransaction,
       pgl.pid           AS lorpid,
       pgl.mode          AS lormode,
       pgl.granted       AS lorgranted,
       pgsa.query        AS lorcurrentquery
FROM pg_locks pgl
         JOIN pg_class pgc ON pgl.relation = pgc.oid
         JOIN pg_stat_activity pgsa ON pgl.pid = pgsa.pid
ORDER BY pgc.relname;

alter table gp_locks_on_relation
    owner to gpadmin;

grant select on gp_locks_on_relation to public;

