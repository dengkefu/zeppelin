create view gp_workfile_usage_per_query (datname, pid, sess_id, command_cnt, usename, query, segid, size, numfiles) as
SELECT gp_workfile_entries.datname,
       gp_workfile_entries.pid,
       gp_workfile_entries.sess_id,
       gp_workfile_entries.command_cnt,
       gp_workfile_entries.usename,
       gp_workfile_entries.query,
       gp_workfile_entries.segid,
       sum(gp_workfile_entries.size)     AS size,
       sum(gp_workfile_entries.numfiles) AS numfiles
FROM gp_toolkit.gp_workfile_entries
GROUP BY gp_workfile_entries.datname, gp_workfile_entries.pid, gp_workfile_entries.sess_id,
         gp_workfile_entries.command_cnt, gp_workfile_entries.usename, gp_workfile_entries.query,
         gp_workfile_entries.segid;

alter table gp_workfile_usage_per_query
    owner to gpadmin;

grant select on gp_workfile_usage_per_query to public;

