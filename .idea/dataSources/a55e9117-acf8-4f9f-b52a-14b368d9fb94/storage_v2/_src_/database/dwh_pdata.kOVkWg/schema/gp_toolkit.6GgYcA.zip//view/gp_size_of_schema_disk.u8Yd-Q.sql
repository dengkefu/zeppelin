create view gp_size_of_schema_disk(sosdnsp, sosdschematablesize, sosdschemaidxsize) as
SELECT un.aunnspname                                     AS sosdnsp,
       COALESCE(sum(sotaid.sotaidtablesize), 0::numeric) AS sosdschematablesize,
       COALESCE(sum(sotaid.sotaididxsize), 0::numeric)   AS sosdschemaidxsize
FROM gp_toolkit.gp_size_of_table_and_indexes_disk sotaid
         JOIN gp_toolkit.__gp_fullname fn ON sotaid.sotaidoid = fn.fnoid
         RIGHT JOIN gp_toolkit.__gp_user_namespaces un ON un.aunnspname = fn.fnnspname
GROUP BY un.aunnspname;

alter table gp_size_of_schema_disk
    owner to gpadmin;

grant select on gp_size_of_schema_disk to public;

