create function __gp_param_setting_on_segments(character varying) returns SETOF gp_toolkit.gp_param_setting_t
    language sql
as
$$
SELECT gp_execution_segment(), $1, current_setting($1);
$$;

alter function __gp_param_setting_on_segments(varchar) owner to gpadmin;

