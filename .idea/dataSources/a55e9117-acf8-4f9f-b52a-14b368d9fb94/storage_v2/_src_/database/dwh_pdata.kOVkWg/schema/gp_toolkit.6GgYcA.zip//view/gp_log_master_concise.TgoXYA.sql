create view gp_log_master_concise (logtime, logdatabase, logsession, logcmdcount, logseverity, logmessage) as
SELECT __gp_log_master_ext.logtime,
       __gp_log_master_ext.logdatabase,
       __gp_log_master_ext.logsession,
       __gp_log_master_ext.logcmdcount,
       __gp_log_master_ext.logseverity,
       __gp_log_master_ext.logmessage
FROM gp_toolkit.__gp_log_master_ext;

alter table gp_log_master_concise
    owner to gpadmin;

