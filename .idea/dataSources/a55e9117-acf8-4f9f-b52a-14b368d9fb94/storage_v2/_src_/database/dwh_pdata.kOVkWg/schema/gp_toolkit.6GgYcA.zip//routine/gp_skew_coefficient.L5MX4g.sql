create function gp_skew_coefficient(targetoid oid, OUT skcoid oid, OUT skccoeff numeric) returns record
    language sql
as
$$
SELECT
        $1 as skcoid,
        CASE
            WHEN skewmean > 0 THEN ((skewdev/skewmean) * 100.0)
            ELSE 0
        END
        AS skccoeff
    FROM
    (
        SELECT STDDEV(segtupcount) AS skewdev, AVG(segtupcount) AS skewmean, COUNT(*) AS skewcnt
        FROM gp_toolkit.gp_skew_details($1)
    ) AS skew

$$;

alter function gp_skew_coefficient(oid, out oid, out numeric) owner to gpadmin;

