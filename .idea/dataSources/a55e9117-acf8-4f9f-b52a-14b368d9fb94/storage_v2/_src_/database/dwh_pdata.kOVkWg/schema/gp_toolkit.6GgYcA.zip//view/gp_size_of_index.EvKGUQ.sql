create view gp_size_of_index
            (soioid, soitableoid, soisize, soiindexschemaname, soiindexname, soitableschemaname, soitablename) as
SELECT soi.soioid,
       soi.soitableoid,
       soi.soisize,
       fnidx.fnnspname AS soiindexschemaname,
       fnidx.fnrelname AS soiindexname,
       fntbl.fnnspname AS soitableschemaname,
       fntbl.fnrelname AS soitablename
FROM (SELECT pgi.indexrelid                             AS soioid,
             pgi.indrelid                               AS soitableoid,
             pg_relation_size(pgi.indexrelid::regclass) AS soisize
      FROM pg_index pgi
               JOIN gp_toolkit.__gp_user_data_tables_readable ut ON pgi.indrelid = ut.autoid) soi
         JOIN gp_toolkit.__gp_fullname fnidx ON soi.soioid = fnidx.fnoid
         JOIN gp_toolkit.__gp_fullname fntbl ON soi.soitableoid = fntbl.fnoid;

alter table gp_size_of_index
    owner to gpadmin;

grant select on gp_size_of_index to public;

