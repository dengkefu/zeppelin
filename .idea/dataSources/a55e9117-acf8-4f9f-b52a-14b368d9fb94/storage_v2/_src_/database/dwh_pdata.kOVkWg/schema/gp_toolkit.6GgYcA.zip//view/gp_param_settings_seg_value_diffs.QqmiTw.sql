create view gp_param_settings_seg_value_diffs(psdname, psdvalue, psdcount) as
SELECT gp_param_settings.paramname  AS psdname,
       gp_param_settings.paramvalue AS psdvalue,
       count(*)                     AS psdcount
FROM gp_toolkit.gp_param_settings() gp_param_settings(paramsegment, paramname, paramvalue)
WHERE gp_param_settings.paramname <> ALL
      (ARRAY ['config_file'::text, 'data_directory'::text, 'gp_contentid'::text, 'gp_dbid'::text, 'hba_file'::text, 'ident_file'::text, 'port'::text])
GROUP BY gp_param_settings.paramname, gp_param_settings.paramvalue
HAVING count(*) < ((SELECT __gp_number_of_segments.numsegments
                    FROM gp_toolkit.__gp_number_of_segments))
ORDER BY gp_param_settings.paramname, gp_param_settings.paramvalue, count(*);

alter table gp_param_settings_seg_value_diffs
    owner to gpadmin;

grant select on gp_param_settings_seg_value_diffs to public;

