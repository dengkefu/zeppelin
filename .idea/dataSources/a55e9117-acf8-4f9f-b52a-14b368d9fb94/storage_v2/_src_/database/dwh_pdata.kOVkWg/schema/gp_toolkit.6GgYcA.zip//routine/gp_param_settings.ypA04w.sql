create function gp_param_settings() returns SETOF gp_toolkit.gp_param_setting_t
    language sql
as
$$
select gp_execution_segment(), name, setting from pg_settings;
$$;

alter function gp_param_settings() owner to gpadmin;

