create view gp_size_of_database(sodddatname, sodddatsize) as
SELECT pg_database.datname               AS sodddatname,
       pg_database_size(pg_database.oid) AS sodddatsize
FROM pg_database
WHERE pg_database.datname <> 'template0'::name
  AND pg_database.datname <> 'template1'::name
  AND pg_database.datname <> 'postgres'::name;

alter table gp_size_of_database
    owner to gpadmin;

grant select on gp_size_of_database to public;

