create view gp_log_command_timings
            (logsession, logcmdcount, logdatabase, loguser, logpid, logtimemin, logtimemax, logduration) as
SELECT __gp_log_master_ext.logsession,
       __gp_log_master_ext.logcmdcount,
       __gp_log_master_ext.logdatabase,
       __gp_log_master_ext.loguser,
       __gp_log_master_ext.logpid,
       min(__gp_log_master_ext.logtime)                                    AS logtimemin,
       max(__gp_log_master_ext.logtime)                                    AS logtimemax,
       max(__gp_log_master_ext.logtime) - min(__gp_log_master_ext.logtime) AS logduration
FROM gp_toolkit.__gp_log_master_ext
WHERE __gp_log_master_ext.logsession IS NOT NULL
  AND __gp_log_master_ext.logcmdcount IS NOT NULL
  AND __gp_log_master_ext.logdatabase IS NOT NULL
GROUP BY __gp_log_master_ext.logsession, __gp_log_master_ext.logcmdcount, __gp_log_master_ext.logdatabase,
         __gp_log_master_ext.loguser, __gp_log_master_ext.logpid;

alter table gp_log_command_timings
    owner to gpadmin;

