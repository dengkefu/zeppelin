create view gp_pgdatabase_invalid (pgdbidbid, pgdbiisprimary, pgdbicontent, pgdbivalid, pgdbidefinedprimary) as
SELECT gp_pgdatabase.dbid           AS pgdbidbid,
       gp_pgdatabase.isprimary      AS pgdbiisprimary,
       gp_pgdatabase.content        AS pgdbicontent,
       gp_pgdatabase.valid          AS pgdbivalid,
       gp_pgdatabase.definedprimary AS pgdbidefinedprimary
FROM gp_pgdatabase
WHERE NOT gp_pgdatabase.valid
ORDER BY gp_pgdatabase.dbid;

alter table gp_pgdatabase_invalid
    owner to gpadmin;

grant select on gp_pgdatabase_invalid to public;

