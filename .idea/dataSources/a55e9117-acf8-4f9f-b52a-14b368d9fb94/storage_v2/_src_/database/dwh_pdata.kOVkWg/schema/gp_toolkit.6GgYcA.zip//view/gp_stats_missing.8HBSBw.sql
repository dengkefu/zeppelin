create view gp_stats_missing(smischema, smitable, smisize, smicols, smirecs) as
SELECT aut.autnspname                  AS smischema,
       aut.autrelname                  AS smitable,
       CASE
           WHEN aut.autrelpages = 0 OR aut.autreltuples = 0::double precision THEN false
           ELSE true
           END                         AS smisize,
       attrs.attcnt                    AS smicols,
       COALESCE(bar.stacnt, 0::bigint) AS smirecs
FROM gp_toolkit.__gp_user_tables aut
         JOIN (SELECT pg_attribute.attrelid,
                      count(*) AS attcnt
               FROM pg_attribute
               WHERE pg_attribute.attnum > 0
                 AND pg_attribute.attisdropped = false
               GROUP BY pg_attribute.attrelid) attrs ON aut.autoid = attrs.attrelid
         LEFT JOIN (SELECT pg_statistic.starelid,
                           count(*) AS stacnt
                    FROM pg_statistic
                    GROUP BY pg_statistic.starelid) bar ON aut.autoid = bar.starelid
WHERE (aut.autrelkind = 'r'::"char" AND (aut.autrelpages = 0 OR aut.autreltuples = 0::double precision))
   OR (bar.stacnt IS NOT NULL AND attrs.attcnt > bar.stacnt);

alter table gp_stats_missing
    owner to gpadmin;

grant select on gp_stats_missing to public;

