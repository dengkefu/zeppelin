create view gp_skew_idle_fractions(sifoid, sifnamespace, sifrelname, siffraction) as
SELECT skew.skewoid AS sifoid,
       pgn.nspname  AS sifnamespace,
       pgc.relname  AS sifrelname,
       skew.skewval AS siffraction
FROM gp_toolkit.__gp_skew_idle_fractions() skew(skewoid, skewval)
         JOIN pg_class pgc ON skew.skewoid = pgc.oid
         JOIN pg_namespace pgn ON pgc.relnamespace = pgn.oid;

alter table gp_skew_idle_fractions
    owner to gpadmin;

grant select on gp_skew_idle_fractions to public;

