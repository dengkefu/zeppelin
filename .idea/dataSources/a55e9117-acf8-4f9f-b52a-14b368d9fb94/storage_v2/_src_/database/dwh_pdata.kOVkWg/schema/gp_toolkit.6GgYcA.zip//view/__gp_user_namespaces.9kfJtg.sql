create view __gp_user_namespaces(aunoid, aunnspname) as
SELECT pg_namespace.oid     AS aunoid,
       pg_namespace.nspname AS aunnspname
FROM pg_namespace
WHERE pg_namespace.nspname !~~ 'pg_%'::text
  AND pg_namespace.nspname <> 'gp_toolkit'::name
  AND pg_namespace.nspname <> 'information_schema'::name;

alter table __gp_user_namespaces
    owner to gpadmin;

grant select on __gp_user_namespaces to public;

