create view __gp_is_append_only(iaooid, iaotype) as
SELECT pgc.oid AS iaooid,
       CASE
           WHEN pgao.relid IS NULL THEN false
           ELSE true
           END AS iaotype
FROM pg_class pgc
         LEFT JOIN pg_appendonly pgao ON pgc.oid = pgao.relid;

alter table __gp_is_append_only
    owner to gpadmin;

grant select on __gp_is_append_only to public;

