create view __gp_user_data_tables_readable
            (autnspname, autrelname, autrelkind, autreltuples, autrelpages, autrelacl, autoid, auttoastoid,
             autrelstorage) as
SELECT aut.autnspname,
       aut.autrelname,
       aut.autrelkind,
       aut.autreltuples,
       aut.autrelpages,
       aut.autrelacl,
       aut.autoid,
       aut.auttoastoid,
       aut.autrelstorage
FROM gp_toolkit.__gp_user_tables aut
WHERE has_table_privilege(aut.autoid, 'select'::text);

alter table __gp_user_data_tables_readable
    owner to gpadmin;

grant select on __gp_user_data_tables_readable to public;

